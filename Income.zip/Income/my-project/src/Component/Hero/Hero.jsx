import React from 'react'

const Hero = () => {
  return (
    <div>
        <div className='w-full'> 
            <div className='pt-20'>
            <div className='justify-center text-center pt-36'>
                <h2 className='text-3xl font-bold'>Manage your money and tracker you <span>expense</span> using </h2>
                <h1 className='mt-5 text-5xl font-bold text-blue-500'>Income Manager</h1>
            </div>
            <div className='justify-center mt-10 text-center pt-7'>
            <button className='p-4 m-3 text-xl text-center text-white bg-blue-500 border rounded-xl hover:bg-red-800'>Tryit on Browser </button>
            </div>
             
          </div>
           <div>
             
           </div>
        </div>
           
    </div>
  )
}

export default Hero