import { Chart } from 'chart.js'
import React from 'react'



const Dashboard = () => {
  return (
    
<div>
<div className='flex-col justify-center text-center'>
         <h2 className='text-2xl font-bold text-blue-600 '>Welcome back!!</h2>
         
    </div>
   
   <div className='flex pt-10'>
    
         <div className='w-2/4 mb-6 pl-7 '>
                <div className= 'pt-5' >
                    <form action="" className='flex-col w-full pl-8 pr-8 m-4 text-blue-700 border-2 border-dashed rounded-lg border-sky-500'>
                        <h1 className='pl-24 mt-3 text-3xl text-blue-500 '>Add expense</h1>
                     <div className='flex flex-col gap-3 text-xl'>
                        <label htmlFor="" className='m-2 text-xl'>Product</label> 
                        <input type="text" name='name' placeholder='eg:phone'required className='p-2 pr-4 border-2 rounded-lg ' />
                     </div>
                        <div className='flex flex-col '>
                        <label htmlFor="" className='m-2 text-xl'>Amount</label>
                        <input type="number" required  className='p-2 pr-4 border-2 rounded-lg'/>
                        </div>  
                        <div className='flex flex-col'>
                            <label htmlFor="" className='m-2 text-xl'>Date</label>
                            <input type="date" required  className='p-2 pr-4 border-2 rounded-lg'/>
                        </div>
                         <div className='flex flex-col mt-4 '>
                           <label htmlFor="" className='pl-2 m-2 text-xl '>Describition</label>
                           <input type="text" name='describition'  required className='p-2 pr-4 border-2 rounded-lg'  />

                         </div>
                        <button className='justify-center p-2 m-2 text-2xl text-center bg-blue-500 cursor-pointer rounded-xl mb-7 hover:bg-transparent hover:text-blue-500'>Add new expense</button>
                    </form>
                </div>
            </div>

            <div className='w-full pl-10'>
                <div className='pt-2 pl-24 '>
                    <h2 className='text-2xl font-bold text-blue-500'>Exsting budget</h2>
                </div>
                 <div className='justify-center w-2/3 pt-5 pl-24 text-center'>
                    <div className='p-2 text-blue-700 border-2 border-blue-500 rounded-lg'>
                        <div className='flex gap-80'>
                        <h2 className='pl-3 text-xl '>User</h2>
                        <p className='pl-20 text-xl'>$12.00 Budgeted</p>
                        </div>
                       
                        <input type='color' id='color' color='white' className='w-full text-blue-600 border-2 border-blue-700 rounde-lg' />
                        <div className='flex gap-80'>
                        <p className='pl-3 text-xl'>$0 spent</p>
                        <p className='pl-20 text-xl'>$12.00 Remained</p>
                        </div>
                       
                    </div>
                     <div>
                        <div className='justify-center text-center'>
                            <h2 className='pt-10 text-3xl font-bold text-blue-700'>Recent expense</h2>
                            <table className='border border-collapse border-gray-500 table-auto' >
                                <thead>
                                <tr className='flex pt-5 text-blue-700 gap-7 '>
                                <th>Name</th>
                                <th >Product</th>
                                <th >Amount</th>
                                <th >Date</th>
                                <th >Describition</th>
                                </tr>
                                </thead>
                               <tbody>
                               <tr >
                                <td >Isaac</td>
                                <td>Telephone</td>
                                <td >2$</td>
                                <td >12/3/2024</td>
                                <td >12Pro max iphone version </td>
                               </tr>
                               </tbody>
                              
                            </table>
                        </div>
                     </div>
                     <Chart/>
                 </div>
            </div>
        </div>
       
   
</div>
    
 
       
  )
}

export default Dashboard