import React from 'react'
import logo from './Images/Logo.jpeg'

const Navbar = () => {
  return (
   <div className='bg-zinc-400 '>
    <div className='flex w-full h-40 bg-white '>
        <div className='flex pl-32 text-center pt-7 '>
        <img src={logo} className='w-8 p-5 text-blue-600' />
            <h1 className='pt-6 text-4xl font-bold text-center text-blue-500 p'> Income Manager</h1>
        </div>
        <div className='flex gap-6  pl-80 ml-96'>
            <div className='justify-center gap-8 text-center  pt-7' >
                <button className='justify-center p-4 m-3 text-xl font-bold text-center text-blue-500 border rounded-lg hover:bg-red-800'>Dashboard </button> 
                <button className='justify-center p-4 font-bold text-center text-white bg-blue-600 border rounded-lg hover:bg-red-800'>Get started </button>
            </div>
        </div>
    </div>
   </div>

  )
}

export default Navbar