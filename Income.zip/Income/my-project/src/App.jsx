import React from 'react'
import Navbar from './Component/Navbar/Navbar'
import Hero from './Component/Hero/Hero'
import Dashboard from './Component/Dashboard/Dashboard'



const App = () => {
  return (
    <main>
     
      <Navbar />
      <Hero />
      <Dashboard />
    </main>
  )
}

export default App